#!/usr/bin/env python3

import rclpy
from rclpy.node import Node


class ParameterExample(Node):

    def __init__(self):
        super().__init__('parameter_example')

        # Declare parameters
        self.declare_parameter('robot_name', 'pixelbotix_robot')
        self.declare_parameter('max_velocity', 2.0)
        self.declare_parameter('enable_navigation', True)

        # Get parameters
        robot_name = self.get_parameter('robot_name').value
        max_vel = self.get_parameter('max_velocity').value
        enable_nav = self.get_parameter('enable_navigation').value

        self.get_logger().info(f'Robot Name: {robot_name}')
        self.get_logger().info(f'Max Velocity: {max_vel}')
        self.get_logger().info(f'Navigation Enabled: {enable_nav}')

        # Create timer to demonstrate parameter updates
        self.timer = self.create_timer(5.0, self.parameter_demo)

    def parameter_demo(self):
        # Fetch current parameters
        params = self.get_parameters([
            'robot_name',
            'max_velocity',
            'enable_navigation'
        ])

        self.get_logger().info('Current parameters:')
        for param in params:
            self.get_logger().info(f'  {param.name}: {param.value}')


def main(args=None):
    rclpy.init(args=args)

    param_node = ParameterExample()

    try:
        rclpy.spin(param_node)
    except KeyboardInterrupt:
        pass
    finally:
        param_node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()



#ros2 param set /parameter_example robot_name "atlas_bot"
#ros2 param set /parameter_example max_velocity 3.5
#ros2 param set /parameter_example enable_navigation false