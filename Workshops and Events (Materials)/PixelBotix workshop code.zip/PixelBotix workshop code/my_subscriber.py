#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from std_msgs.msg import String


class MySubscriber(Node):

    def __init__(self):
        super().__init__('my_subscriber')

        # Create subscriber
        self.subscription = self.create_subscription(
            String,
            'chatter',
            self.listener_callback,
            10
        )

        # Prevent unused variable warning
        self.subscription

    def listener_callback(self, msg):
        self.get_logger().info(f'I heard: "{msg.data}"')


def main(args=None):
    rclpy.init(args=args)

    # Create and run subscriber node
    subscriber_node = MySubscriber()

    try:
        rclpy.spin(subscriber_node)
    except KeyboardInterrupt:
        pass
    finally:
        # Cleanup
        subscriber_node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
