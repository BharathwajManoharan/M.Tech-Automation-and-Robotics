#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from example_interfaces.srv import AddTwoInts


class AddTwoIntsClient(Node):

    def __init__(self):
        super().__init__('add_two_ints_client')

        # Create client
        self.client = self.create_client(AddTwoInts, 'add_two_ints')

        # Wait for service to be available
        while not self.client.wait_for_service(timeout_sec=1.0):
            self.get_logger().info('Waiting for add_two_ints service...')

        # Create request object
        self.request = AddTwoInts.Request()

    def send_request(self, a, b):
        self.request.a = a
        self.request.b = b

        self.future = self.client.call_async(self.request)
        rclpy.spin_until_future_complete(self, self.future)

        return self.future.result()


def main(args=None):
    rclpy.init(args=args)

    client = AddTwoIntsClient()

    # Send numbers to server
    a = 5
    b = 7
    response = client.send_request(a, b)

    client.get_logger().info(
        f'Result of {a} + {b} = {response.sum}'
    )

    client.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()
