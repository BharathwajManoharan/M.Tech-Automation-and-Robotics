#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from turtlesim.msg import Pose


class TurtlePositionSubscriber(Node):

    def __init__(self):
        super().__init__('turtle_position_subscriber')

        # Subscribe to turtle pose
        self.subscription = self.create_subscription(
            Pose,
            '/turtle1/pose',
            self.pose_callback,
            10
        )

    def pose_callback(self, msg):
        self.get_logger().info(
            f'Turtle Position: x={msg.x:.2f}, y={msg.y:.2f}, theta={msg.theta:.2f}'
        )


def main(args=None):
    rclpy.init(args=args)

    position_subscriber = TurtlePositionSubscriber()
    position_subscriber.get_logger().info("Listening to turtle position...")

    try:
        rclpy.spin(position_subscriber)
    except KeyboardInterrupt:
        pass
    finally:
        position_subscriber.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
