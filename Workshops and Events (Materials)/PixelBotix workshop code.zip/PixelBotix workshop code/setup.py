# Add the finished nodes to the setup.py file
    entry_points={
        'console_scripts': [
            'my_publisher = my_robot.my_publisher:main',
            'my_subscriber = my_robot.my_subscriber:main',
            'turtle_controller = my_robot.turtle_controller:main',
            'turtle_position = my_robot.turtle_position:main',
            'add_two_ints_server = my_robot.add_two_ints_server:main',
            'add_two_ints_client = my_robot.add_two_ints_client:main',
            'parameter_example = my_robot.parameter_example:main',
        ],
    },
)
