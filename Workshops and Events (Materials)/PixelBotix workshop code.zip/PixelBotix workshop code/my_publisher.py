#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from std_msgs.msg import String


class MyPublisher(Node):

    def __init__(self):
        super().__init__('my_publisher')

        # Create publisher
        self.publisher_ = self.create_publisher(String, 'chatter', 10)

        # Create timer for publishing
        timer_period = 1.0  # seconds
        self.timer = self.create_timer(timer_period, self.timer_callback)

        self.count = 0

    def timer_callback(self):
        # Create message
        msg = String()
        msg.data = f'Hello ROS 2: {self.count}'

        # Publish message
        self.publisher_.publish(msg)
        self.get_logger().info(f'Publishing: "{msg.data}"')

        self.count += 1


def main(args=None):
    rclpy.init(args=args)

    # Create and run publisher node
    publisher_node = MyPublisher()

    try:
        rclpy.spin(publisher_node)
    except KeyboardInterrupt:
        pass
    finally:
        # Cleanup
        publisher_node.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
