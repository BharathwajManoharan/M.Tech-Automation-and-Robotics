#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from geometry_msgs.msg import Twist


class TurtleController(Node):

    def __init__(self):
        super().__init__('turtle_controller')

        # Publisher to control turtle
        self.publisher_ = self.create_publisher(Twist, '/turtle1/cmd_vel', 10)

        # Create timer
        timer_period = 0.1  # seconds
        self.timer = self.create_timer(timer_period, self.timer_callback)

        self.start_time = self.get_clock().now()

    def timer_callback(self):
        # Create Twist message
        move_cmd = Twist()

        # Make turtle move in a circle
        move_cmd.linear.x = 2.0     # Constant forward speed
        move_cmd.angular.z = 1.0    # Constant turning speed

        # Publish command
        self.publisher_.publish(move_cmd)
        self.get_logger().info(
            f'Moving turtle: linear={move_cmd.linear.x}, angular={move_cmd.angular.z}'
        )


def main(args=None):
    rclpy.init(args=args)

    turtle_controller = TurtleController()

    try:
        rclpy.spin(turtle_controller)
    except KeyboardInterrupt:
        pass
    finally:
        turtle_controller.destroy_node()
        rclpy.shutdown()


if __name__ == '__main__':
    main()
